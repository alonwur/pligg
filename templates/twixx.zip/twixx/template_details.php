<?php
	$template_info['name'] = 'Twixx'; // do not use the _ character. use - instead
	$template_info['desc'] = 'Twixx by www.Pligg-Templates.net';
	$template_info['author'] = 'Pligg-Templates.net';
	$template_info['support'] = 'http://www.pligg-templates.net';
	$template_info['version'] = '1.2.0';
	$template_info['designed_for_pligg_version'] = '1.2.0';
?>
