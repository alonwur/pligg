------------------ ABOUT -------------------
Wistie is a free Pligg template created for distribution for Pligg 1.0. Wistie uses minimal amounts of graphics, including icons, and is designed as a great starting point for future templates to be based off of because of this minimal design.

Wistie is a collaborative Pligg template that was created by Christie "Distie" Heikkinen and Eric "Yankidank" Heikkinen. The design and original HTML/CSS code was created by Christie, and the template for Pligg was created by Eric.


----------------- LICENSE ------------------

This work has been licensed under the Attribution-Noncommercial-Share Alike 3.0 Unported.
In short, you are free to share and remix this work under the following conditions:

    * You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
    * You may not use this work for commercial purposes.
    * If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.

